# FocusFlow

A calm, responsive daily task planner built with plain HTML, CSS, and JavaScript. FocusFlow runs in your browser, saves tasks locally, and needs no install, build step, or account.

## Run it

Open `index.html` in a modern browser. For local development, you can also run a static server from this folder, for example:

```sh
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Features

- Today, upcoming, and completed task views
- Work, personal, and wellbeing categories
- Add and complete tasks, with browser-local persistence
- Daily completion progress and a dark theme
- Responsive layout for desktop and mobile
- No frameworks, package installs, or backend

Tasks stay in the browser's local storage. Clearing browser data removes them. The Google Fonts connection is optional; system fallbacks keep the app usable offline.

## Publish on GitHub

Create a new repository on GitHub, then upload these files or push this folder with Git. GitHub Pages can host the app as a static site: in the repository, open **Settings → Pages**, select the default branch and root folder, and save.

## License

MIT. See [LICENSE](LICENSE).
